from random import randrange, choice
from fonctions import liste_coord, créa_dico, initialisation_dico, pas_de_barre


def init(deb_x, deb_y, width, height):

    fin_x = deb_x + width
    fin_y = deb_y + height

    marge = 1 / 12 * min(width, height)

    traits_max_x = (width // (2 * marge - 1)) + 1
    traits_max_y = (height // (2 * marge - 1)) + 1

    nbr_x = randrange(2, min(traits_max_x, traits_max_y))

    nbr_y = randrange(nbr_x - 1, min(nbr_x + (randrange(7)), traits_max_y))

    coord_x = liste_coord(deb_x, fin_x, nbr_x, marge)

    coord_y = liste_coord(deb_y, fin_y, nbr_y, marge)

    rencontre = créa_dico(coord_x)
    initialisation_dico(rencontre, deb_x, deb_y, fin_x, fin_y, coord_y)

    dico_x = créa_dico(coord_x)
    initialisation_dico(dico_x, deb_x, deb_y, fin_x, fin_y, coord_y)

    dico_y = créa_dico(coord_y)
    initialisation_dico(dico_y, deb_y, deb_x, fin_y, fin_x, coord_x)

    possibilités_début_y = {}
    ou_il_faut_passer = {}
    for deb_y in coord_y:
        possibilités_début_y[deb_y] = list(coord_x)
        ou_il_faut_passer[deb_y] = []

    # faire toutes les colonnes aléatoirement
    place_prise_par_colonnes = [height, 0]
    place_prise_par_lignes = [width, 0]

    for i in range(len(coord_x) - 2):

        debut = choice(coord_y)

        fin = choice(coord_y)

        while debut == fin:
            fin = choice(coord_y)

        place_prise_par_colonnes[0] = min(place_prise_par_colonnes[0], debut, fin)
        place_prise_par_colonnes[1] = max(place_prise_par_colonnes[1], debut, fin)

        dico_x[coord_x[i + 2]].append([debut, fin])

        if debut == 0 or debut == height:
            rencontre[coord_x[i + 2]].append(debut)
        else:
            possibilités_début_y[debut].remove(coord_x[i + 2])
            ou_il_faut_passer[debut].append(coord_x[i + 2])

        if fin == 0 or fin == height:
            rencontre[coord_x[i + 2]].append(fin)
        else:
            possibilités_début_y[fin].remove(coord_x[i + 2])
            ou_il_faut_passer[fin].append(coord_x[i + 2])

        for deb_y in possibilités_début_y:
            if (fin < deb_y and debut < deb_y) or (fin > deb_y and debut > deb_y):
                possibilités_début_y[deb_y].remove(coord_x[i + 2])

    # essayer que toutes les colonnes fassent toute la longueur de l'écran

    pas_de_barre(
        coord_x,
        rencontre,
        dico_x,
        place_prise_par_colonnes,
        width,
        height,
        marge,
    )

    for deb_y in possibilités_début_y:
        possibilités_début_y[deb_y].sort()

        if ou_il_faut_passer[deb_y] != []:

            i_min = 1
            while possibilités_début_y[deb_y][i_min] < min(ou_il_faut_passer[deb_y]):
                i_min += 1

            i_max = 0
            while possibilités_début_y[deb_y][i_max] < max(ou_il_faut_passer[deb_y]):
                i_max += 1

            debut = possibilités_début_y[deb_y][randrange(i_min)]

            fin = possibilités_début_y[deb_y][
                randrange(i_max, len(possibilités_début_y[deb_y]))
            ]

        else:
            debut = choice(possibilités_début_y[deb_y])

            fin = choice(possibilités_début_y[deb_y])

        if deb_y != 0 and deb_y != height:
            dico_y[deb_y].append([debut, fin])

        place_prise_par_lignes[0] = min(place_prise_par_lignes[0], debut, fin)
        place_prise_par_lignes[1] = max(place_prise_par_lignes[1], debut, fin)

        for deb_x in coord_x:
            for i in range(len(dico_x[deb_x])):
                if (
                    dico_x[deb_x][i][0] <= deb_y <= dico_x[deb_x][i][1]
                    or dico_x[deb_x][i][0] >= deb_y >= dico_x[deb_x][i][1]
                ) and (
                    debut == deb_x
                    or fin == deb_x
                    or (fin < deb_x < debut)
                    or (debut < deb_x < fin)
                ):
                    rencontre[deb_x].append(deb_y)
                    # rencontre[deb_x].sort()

    pas_de_barre(
        coord_y,
        rencontre,
        dico_y,
        place_prise_par_lignes,
        height,
        width,
        marge,
    )

    # del dico_x[min(dico_x)]
    # del dico_x[max(dico_x)]
    # del dico_y[min(dico_y)]
    # del dico_y[max(dico_y)]

    print("dico_x: ", dico_x)
    print("dico_y: ", dico_y)

    return {
        "width": width,
        "height": height,
        "rencontre": rencontre,
        "dico_x": dico_x,
        "dico_y": dico_y,
        "possibilités_début_y": possibilités_début_y,
        "ou_il_faut_passer": ou_il_faut_passer,
    }
