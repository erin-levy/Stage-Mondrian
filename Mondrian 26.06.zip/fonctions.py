from random import randrange, choice


# Pour quadrillage 4 :


def liste_coord(deb, fin, nbr_coord, marge):
    marge_init = marge
    liste = [deb, fin]
    for i in range(nbr_coord):
        trop_près = 1
        garde_fou = 0
        while trop_près != 0:
            if garde_fou >= 10:
                marge -= 10
            elif garde_fou >= 20:
                marge -= 20
            elif garde_fou >= 30:
                marge -= 30
            coord_nouv = randrange(int(deb + marge), int(fin - marge))
            trop_près = 0
            for coord_deja_la in liste:
                if abs(coord_nouv - coord_deja_la) < marge:
                    trop_près += 1
                    garde_fou = 0
            garde_fou += 1
            marge = marge_init

        liste.append(coord_nouv)
    return liste


def créa_dico(liste_clés):
    dico = {}
    for clé in liste_clés:
        dico[clé] = []
    return dico


def initialisation_dico(dico, deb_c1, deb_c2, fin_c1, fin_c2, coord_c2):
    dico[deb_c1].append([deb_c2, fin_c2, fin_c2])
    dico[fin_c1].append([deb_c2, fin_c2, fin_c2])


def pas_de_barre(
    coord_c1, rencontre, dico_c2, place_prise_par_trait, fin_c1, fin_c2, marge
):
    if place_prise_par_trait[0] != 0:
        coord_encore_nouv = randrange(int(marge), int(fin_c1 - marge))
        coord_c1.append(coord_encore_nouv)
        rencontre[coord_encore_nouv] = [0, min(place_prise_par_trait)]
        dico_c2[coord_encore_nouv] = [[0, min(place_prise_par_trait)]]

    if place_prise_par_trait[1] != fin_c2:
        coord_encore_nouv = randrange(int(marge), int(fin_c1 - marge))
        coord_c1.append(coord_encore_nouv)
        rencontre[coord_encore_nouv] = [max(place_prise_par_trait), fin_c2]
        dico_c2[coord_encore_nouv] = [[max(place_prise_par_trait), fin_c2]]


def déplacement_quadrillage(dico, d_coord, d_autre_coord):

    for coord in dico:
        for i in range(len(dico[coord])):
            dico[coord][i][0] += d_autre_coord
            dico[coord][i][1] += d_autre_coord

    dic_nouv = {}
    for x in dico:
        dic_nouv[x + d_coord] = dico[x]
    return dic_nouv


def zoom_quadrillage(c1, autre_coord, dico_c1, grandissement):

    dic_nouv_x = {}
    for coord1 in dico_c1:
        for i in range(len(dico_c1[coord1])):
            dico_c1[coord1][i][0] += (
                dico_c1[coord1][i][0] - autre_coord
            ) * grandissement
            dico_c1[coord1][i][1] += (
                dico_c1[coord1][i][1] - autre_coord
            ) * grandissement
            dic_nouv_x[coord1 + (coord1 - c1) * grandissement] = dico_c1[coord1]

    return dic_nouv_x


# def fusion


#########################
# Pour couleurs 4:


def dichotomie(liste, val):
    deb = 0
    fin = len(liste) - 1
    milieu = (deb + fin) // 2
    while deb <= fin:
        if liste[milieu] == val:
            return milieu
        elif liste[milieu] < val:
            deb = milieu + 1
        else:
            fin = milieu - 1
        milieu = (deb + fin) // 2
    return milieu


def trouver_lignes(coord, coord_2, dico):
    liste_coord = list(dico.keys())
    liste_coord.sort()

    i1 = dichotomie(liste_coord, coord)
    i2 = i1 + 1

    c_1 = liste_coord[i1]
    c_2 = liste_coord[i2]

    n1 = 0
    while coord_2 < min(dico[c_1][n1]) or coord_2 > max(dico[c_1][n1]):
        if n1 != len(dico[c_1]) - 1:
            n1 += 1
        else:
            n1 = 0
            i1 -= 1
            c_1 = liste_coord[i1]

    n2 = 0

    while coord_2 < min(dico[c_2][n2]) or coord_2 > max(dico[c_2][n2]):
        if n2 != len(dico[c_2]) - 1:
            n2 += 1
        else:
            n2 = 0
            i2 += 1
            c_2 = liste_coord[i2]

    return (c_1, c_2)


#########################
# Pour fenêtre Mondrian:


def clé_int(dico):
    dico_nouv = {int(cle): valeur for cle, valeur in dico.items()}
    return dico_nouv
