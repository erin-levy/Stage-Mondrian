from random import randrange, choice
from pyglet import shapes
from fonctions import (
    zoom_quadrillage,
    déplacement_quadrillage,
)
from init import init


class Grille4:
    def __init__(self, width, height):
        self.largeur_trait = 7

        self.width = width
        self.height = height

        I = init(0, 0, self.width, self.height)

        self.width = I["width"]
        self.height = I["height"]
        self.rencontre = I["rencontre"]
        self.dico_x = I["dico_x"]
        self.dico_y = I["dico_y"]
        self.possibilités_début_y = I["possibilités_début_y"]
        self.ou_il_faut_passer = I["ou_il_faut_passer"]

    def déplacement(self, dx, dy):
        self.dico_x = déplacement_quadrillage(self.dico_x, dx, dy)

        self.dico_y = déplacement_quadrillage(self.dico_y, dy, dx)

    def zoom(self, x, y, grandissement):
        if grandissement != 0:
            self.width += grandissement * self.width
            self.height += grandissement * self.height

            self.largeur_trait *= 1 + grandissement

            self.dico_x = zoom_quadrillage(
                x,
                y,
                self.dico_x,
                grandissement,
            )
            self.dico_y = zoom_quadrillage(
                y,
                x,
                self.dico_y,
                grandissement,
            )

    def draw(self):
        for x in self.dico_x:
            for traits_x in range(len(self.dico_x[x])):
                if len(self.dico_x[x][traits_x]) == 2:
                    shapes.Line(
                        x,
                        self.dico_x[x][traits_x][0],
                        x,
                        self.dico_x[x][traits_x][1],
                        width=self.largeur_trait,
                        color=(0, 0, 0),
                    ).draw()

        for y in self.dico_y:
            for traits_y in range(len(self.dico_y[y])):
                if len(self.dico_y[y][traits_y]) == 2:
                    shapes.Line(
                        self.dico_y[y][traits_y][0],
                        y,
                        self.dico_y[y][traits_y][1],
                        y,
                        width=self.largeur_trait,
                        color=(0, 0, 0),
                    ).draw()
