def prolongement(self):
    if min(self.dico_x) > -20:
        nouv_I = init(min(self.dico_x) - self.width, 0, self.width, self.height)

        self.dico_x |= nouv_I["dico_x"]
        self.dico_y |= nouv_I["dico_y"]

    if max(self.dico_x) < self.width + 20:
        nouv_I = init(max(self.dico_x), 0, self.width, self.height)

        self.dico_x |= nouv_I["dico_x"]
        self.dico_y |= nouv_I["dico_y"]

    if min(self.dico_y) > -20:
        nouv_I = init(0, min(self.dico_y) - self.height, self.width, self.height)

        self.dico_x |= nouv_I["dico_x"]
        self.dico_y |= nouv_I["dico_y"]

    if max(self.dico_y) < self.height + 20:
        nouv_I = init(0, max(self.dico_x), self.width, self.height)

        self.dico_x |= nouv_I["dico_x"]
        self.dico_y |= nouv_I["dico_y"]
