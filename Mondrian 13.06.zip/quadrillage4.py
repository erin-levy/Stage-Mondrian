from random import randrange, choice
from pyglet import shapes


class Grille4:
    def __init__(self, width, height):

        self.quadrillage = []

        self.nbr_x = randrange(2, 11)
        self.nbr_y = randrange(2, 11)
        marge = 50

        self.coord_x = [0, width]
        for i in range(self.nbr_x):
            trop_près = 1
            garde_fou = 0
            while trop_près != 0 and garde_fou <= 50:
                x_nouv = randrange(marge, width - marge)
                trop_près = 0
                for x_deja_la in self.coord_x:
                    if abs(x_nouv - x_deja_la) < marge:
                        trop_près += 1
                garde_fou += 1

            self.coord_x.append(x_nouv)

        self.rencontre = {}
        for x in self.coord_x:
            self.rencontre[x] = []
        self.rencontre[0].append(0)
        self.rencontre[0].append(height)
        self.rencontre[width].append(0)
        self.rencontre[width].append(height)

        debut_fin_x = {}
        for x in self.coord_x:
            debut_fin_x[x] = []
        debut_fin_x[0].append(0)
        debut_fin_x[0].append(height)
        debut_fin_x[width].append(0)
        debut_fin_x[width].append(height)

        self.coord_y = [0, height]
        for i in range(self.nbr_y):
            trop_près = 1
            while trop_près != 0:
                y_nouv = randrange(marge, height - marge)
                trop_près = 0
                for y_deja_la in self.coord_y:
                    if abs(y_nouv - y_deja_la) < marge and y_nouv != y_deja_la:
                        trop_près += 1
            self.coord_y.append(y_nouv)

        possibilités_début_y = {}
        ou_il_faut_passer = {}
        for y in self.coord_y[2:]:
            possibilités_début_y[y] = list(self.coord_x)
            ou_il_faut_passer[y] = []

        # faire toutes les colonnes aléatoirement
        place_prise_par_colonnes = [height, 0]

        for i in range(len(self.coord_x) - 2):

            debut = choice(self.coord_y)

            fin = choice(self.coord_y)

            while debut == fin:
                fin = choice(self.coord_y)

            place_prise_par_colonnes[0] = min(place_prise_par_colonnes[0], debut, fin)
            place_prise_par_colonnes[1] = max(place_prise_par_colonnes[1], debut, fin)

            debut_fin_x[self.coord_x[i + 2]].append(debut)
            debut_fin_x[self.coord_x[i + 2]].append(fin)

            if debut == 0 or debut == height:
                self.rencontre[self.coord_x[i + 2]].append(debut)
            else:
                possibilités_début_y[debut].remove(self.coord_x[i + 2])
                ou_il_faut_passer[debut].append(self.coord_x[i + 2])

            if fin == 0 or fin == height:
                self.rencontre[self.coord_x[i + 2]].append(fin)
            else:
                possibilités_début_y[fin].remove(self.coord_x[i + 2])
                ou_il_faut_passer[fin].append(self.coord_x[i + 2])

            for y in possibilités_début_y:
                if (fin < y and debut < y) or (fin > y and debut > y):
                    possibilités_début_y[y].remove(self.coord_x[i + 2])

            self.quadrillage.append(
                shapes.Line(
                    self.coord_x[i + 2],
                    debut,
                    self.coord_x[i + 2],
                    fin,
                    width=7,
                    color=(0, 0, 0),
                ),
            )

        # essayer que toutes les colonnes fassent toute la longueur de l'écran

        if place_prise_par_colonnes[0] != 0:
            x_encore_nouv = randrange(width)
            self.coord_x.append(x_encore_nouv)
            self.rencontre[x_encore_nouv] = [0, min(place_prise_par_colonnes)]
            debut_fin_x[x_encore_nouv] = [0, min(place_prise_par_colonnes)]
            self.quadrillage.append(
                shapes.Line(
                    x_encore_nouv,
                    0,
                    x_encore_nouv,
                    min(place_prise_par_colonnes),
                    width=7,
                    color=(0, 0, 0),
                ),
            )

        if place_prise_par_colonnes[1] != height:
            x_encore_nouv = randrange(width)
            self.coord_x.append(x_encore_nouv)
            self.rencontre[x_encore_nouv] = [max(place_prise_par_colonnes), height]
            debut_fin_x[x_encore_nouv] = [max(place_prise_par_colonnes), height]
            self.quadrillage.append(
                shapes.Line(
                    x_encore_nouv,
                    max(place_prise_par_colonnes),
                    x_encore_nouv,
                    height,
                    width=7,
                    color=(0, 0, 0),
                ),
            )

        for y in possibilités_début_y:
            possibilités_début_y[y].sort()

            if ou_il_faut_passer[y] != []:
                if max(possibilités_début_y[y]) < min(ou_il_faut_passer[y]):
                    i_min = len(possibilités_début_y[y]) - 1
                    i_max = len(possibilités_début_y[y]) - 1
                else:
                    i_min = 1
                    while possibilités_début_y[y][i_min] < min(ou_il_faut_passer[y]):
                        i_min += 1

                    i_max = 0
                    while possibilités_début_y[y][i_max] < max(ou_il_faut_passer[y]):
                        i_max += 1

                debut = possibilités_début_y[y][randrange(i_min)]

                fin = possibilités_début_y[y][
                    randrange(i_max, len(possibilités_début_y[y]))
                ]
            else:
                debut = choice(possibilités_début_y[y])

                fin = choice(possibilités_début_y[y])

            for x in self.coord_x:
                if (
                    debut_fin_x[x][0] <= y <= debut_fin_x[x][1]
                    or debut_fin_x[x][0] >= y >= debut_fin_x[x][1]
                ) and (
                    debut == x or fin == x or (fin < x < debut) or (debut < x < fin)
                ):
                    self.rencontre[x].append(y)
                    self.rencontre[x].sort()

            self.quadrillage.append(
                shapes.Line(
                    debut,
                    y,
                    fin,
                    y,
                    width=7,
                    color=(0, 0, 0),
                ),
            )

        self.coord_x.sort()
        self.coord_y.sort()

        print("rencontre : ", self.rencontre)
        print("coord x :", self.coord_x)
        print("coord y :", self.coord_y)

    def draw(self):
        for lignes in self.quadrillage:
            lignes.draw()
