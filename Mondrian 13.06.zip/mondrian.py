import pyglet
from pyglet import shapes
from pyglet.window import key
import time

from quadrillage_1 import Grille
from carrés import Carrés
from quadrillage_2 import Grille2
from quadrillage3 import Grille3
from quadrillage4 import Grille4
from carrés2 import Carrés2
from quadrillage4bis import Grille4bis
from couleurs1 import Couleurs1
from couleurs2 import Couleurs2
from couleurs3 import Couleurs3


class Mondrian(pyglet.window.Window):
    def __init__(self):
        super().__init__(700, 700, "Tableau Mondrian", resizable=True)

        width = 700
        height = 700

        self.fond_blanc = shapes.Rectangle(0, 0, width, height, color=(255, 255, 255))

        self.grille = Grille(width, height)
        self.carrés = Carrés(width, height)
        self.grille2 = Grille2(width, height)
        self.grille3 = Grille3(width, height)
        self.grille4 = Grille4(width, height)
        self.carrés2 = Carrés2(width, height)
        self.grille4bis = Grille4bis(width, height)
        self.couleurs1 = Couleurs1(width, self.grille4.coord_x, self.grille4.rencontre)
        self.couleurs2 = Couleurs2(self.grille4.coord_x, self.grille4.rencontre)
        # self.couleurs3 = Couleurs3(self.grille4.coord_x, self.grille4.rencontre)

    def on_key_press(self, symbol, modifiers):
        if symbol == key.ENTER:
            debut = time.time()
            mondrian = Mondrian()
            fin = time.time()
            print("temps=", fin - debut)
            Mondrian.close(self)

    def on_draw(self):
        self.fond_blanc.draw()
        # self.couleurs1.draw()
        self.couleurs2.draw()
        # self.couleurs3.draw()
        # self.carrés.draw()
        # self.carrés2.draw()
        # self.grille.draw()
        # self.grille2.draw()
        # self.grille3.draw()
        self.grille4.draw()
        # self.grille4bis.draw()


mondrian = Mondrian()


pyglet.app.run()
