from random import randrange
from pyglet import shapes


class Grille4bis:
    def __init__(self, width, height):

        self.quadrillage = []

        coord_x = [0, width]
        for i in range(randrange(1, 4)):
            trop_près = 1
            while trop_près != 0:
                x_nouv = randrange(width)
                trop_près = 0
                for x_deja_la in coord_x:
                    if abs(x_nouv - x_deja_la) < 50 and x_nouv != x_deja_la:
                        trop_près += 1

            coord_x.append(x_nouv)

        coord_y = [0, height]
        for i in range(randrange(1, 4)):
            trop_près = 1
            while trop_près != 0:
                y_nouv = randrange(height)
                trop_près = 0
                for y_deja_la in coord_y:
                    if abs(y_nouv - y_deja_la) < 50 and y_nouv != y_deja_la:
                        trop_près += 1
            coord_y.append(y_nouv)

        possibilités_début_x = {}
        ou_il_faut_passer = {}
        for x in coord_x[2:]:
            possibilités_début_x[x] = list(coord_y)
            ou_il_faut_passer[x] = []

        # faire toutes les colonnes aléatoirement
        # essayer que toutes les colonnes fassent toute la longueur de l'écran
        place_prise_par_lignes = []

        for i in range(len(coord_y) - 2):

            debut = coord_x[randrange(len(coord_x))]
            place_prise_par_lignes.append(debut)

            fin = coord_x[randrange(len(coord_x))]
            while debut == fin:
                fin = coord_x[randrange(len(coord_x))]
            place_prise_par_lignes.append(fin)

            if fin != 0 and fin != width:
                possibilités_début_x[fin].remove(coord_y[i + 2])
                ou_il_faut_passer[fin].append(coord_y[i + 2])

            if debut != 0 and debut != width:
                possibilités_début_x[debut].remove(coord_y[i + 2])
                ou_il_faut_passer[debut].append(coord_y[i + 2])

            for x in possibilités_début_x:
                if (fin < x and debut < x) or (fin > x and debut > x):
                    possibilités_début_x[x].remove(coord_y[i + 2])

            self.quadrillage.append(
                shapes.Line(
                    debut,
                    coord_y[i + 2],
                    fin,
                    coord_y[i + 2],
                    width=7,
                    color=(0, 0, 0),
                ),
            )

        if min(place_prise_par_lignes) != 0:
            y_encore_nouv = randrange(height)
            coord_x.append(y_encore_nouv)
            self.quadrillage.append(
                shapes.Line(
                    0,
                    y_encore_nouv,
                    min(place_prise_par_lignes),
                    y_encore_nouv,
                    width=7,
                    color=(0, 0, 0),
                ),
            )

        if max(place_prise_par_lignes) != height:
            y_encore_nouv = randrange(height)
            coord_y.append(y_encore_nouv)
            self.quadrillage.append(
                shapes.Line(
                    max(place_prise_par_lignes),
                    y_encore_nouv,
                    width,
                    y_encore_nouv,
                    width=7,
                    color=(0, 0, 0),
                ),
            )

        for x in possibilités_début_x:
            possibilités_début_x[x].sort()
            i_min = len(possibilités_début_x[x]) // 2
            i_max = len(possibilités_début_x[x]) // 2
            if ou_il_faut_passer[x] != []:
                if max(possibilités_début_x[x]) < min(ou_il_faut_passer[x]):
                    i_min = len(possibilités_début_x[x]) - 1
                    i_max = len(possibilités_début_x[x]) - 1
                else:
                    i_min = 1
                    while possibilités_début_x[x][i_min] < min(ou_il_faut_passer[x]):
                        i_min += 1

                    i_max = 0
                    while possibilités_début_x[x][i_max] < max(ou_il_faut_passer[x]):
                        i_max += 1

            debut = possibilités_début_x[x][randrange(0, i_min)]

            fin = possibilités_début_x[x][
                randrange(i_max, len(possibilités_début_x[x]))
            ]

            self.quadrillage.append(
                shapes.Line(
                    x,
                    debut,
                    x,
                    fin,
                    width=7,
                    color=(0, 0, 0),
                ),
            )

    def draw(self):
        for lignes in self.quadrillage:
            lignes.draw()
